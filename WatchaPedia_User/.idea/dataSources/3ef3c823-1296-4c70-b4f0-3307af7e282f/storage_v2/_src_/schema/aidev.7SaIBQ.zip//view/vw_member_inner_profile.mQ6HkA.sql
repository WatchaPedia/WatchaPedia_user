create definer = root@localhost view vw_member_inner_profile as
select `aidev`.`tb_member`.`mem_userid` AS `mem_userid`,
       `aidev`.`tb_member`.`mem_name`   AS `mem_name`,
       `aidev`.`tb_member`.`mem_hp`     AS `mem_hp`,
       `aidev`.`tb_order`.`or_num`      AS `or_num`,
       `aidev`.`tb_order`.`or_zipcode`  AS `or_zipcode`,
       `aidev`.`tb_member`.`mem_idx`    AS `m`,
       `aidev`.`tb_order`.`or_idx`      AS `o`
from (`aidev`.`tb_member` left join `aidev`.`tb_order`
      on ((`aidev`.`tb_member`.`mem_idx` = `aidev`.`tb_order`.`or_idx`)));

