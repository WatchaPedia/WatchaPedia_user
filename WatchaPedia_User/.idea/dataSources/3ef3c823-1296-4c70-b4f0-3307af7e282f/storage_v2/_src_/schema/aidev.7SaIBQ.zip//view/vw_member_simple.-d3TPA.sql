create definer = root@localhost view vw_member_simple as
select `aidev`.`tb_member`.`mem_idx`    AS `mem_idx`,
       `aidev`.`tb_member`.`mem_userid` AS `mem_userid`,
       `aidev`.`tb_member`.`mem_userpw` AS `mem_userpw`,
       `aidev`.`tb_member`.`mem_name`   AS `mem_name`,
       `aidev`.`tb_member`.`mem_hp`     AS `mem_hp`
from `aidev`.`tb_member`;

